
import smtplib
from email.mime.text import MIMEText

SENDER = "piyushradhe14@gmail.com"
APP_PASSWORD = "szxi wyoq xjsz tbrf"

def send_email(name, email):
    msg = MIMEText(f"Hello {name}, your account has been created successfully.")
    msg["Subject"] = "Account Created"
    msg["From"] = SENDER
    msg["To"] = email

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(SENDER, APP_PASSWORD)
        server.sendmail(SENDER, email, msg.as_string())

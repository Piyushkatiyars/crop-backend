
from fastapi import FastAPI, Depends
from pydantic import BaseModel
from database import Base, engine, get_db
from sqlalchemy.orm import Session
from models import User
from auth import hash_password, verify_password
from email_utils import send_email

Base.metadata.create_all(bind=engine)

app = FastAPI()

class Register(BaseModel):
    name: str
    email: str
    password: str

class Login(BaseModel):
    email: str
    password: str

@app.post("/register")
def register(data: Register, db: Session = Depends(get_db)):
    user = User(name=data.name, email=data.email, password=hash_password(data.password))
    db.add(user)
    db.commit()
    send_email(data.name, data.email)
    return {"message": "User created and email sent!"}

@app.post("/login")
def login(data: Login, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()
    if not user or not verify_password(data.password, user.password):
        return {"error": "Invalid email or password"}
    return {"message": "Login successful!"}


from fastapi import FastAPI
from sqlalchemy import create_engine, text
import os

DATABASE_URL = os.getenv("DATABASE_URL")

engine = create_engine(DATABASE_URL)

app = FastAPI()

@app.get("/")
def home():
    with engine.connect() as conn:
        result = conn.execute(text("SELECT 'Backend Connected Successfully'"))
        return {"message": result.scalar()}
